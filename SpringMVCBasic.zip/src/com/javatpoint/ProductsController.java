package com.javatpoint;

import javax.persistence.QueryHint;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ProductsController {

	@RequestMapping("Products/Index")
	public ModelAndView index(){
		String message="Products/Index Displayed";
		return new ModelAndView("products","message",message);
	}
	
	@RequestMapping("Products/Browse")
	public ModelAndView Browse(){
		String message="Browse Displayed";
		return new ModelAndView("products","message",message);
	}
	
	@RequestMapping("Products/Details")
	public ModelAndView Details(@RequestParam String Id){
		String message="Details Displayed for Id="+Id;
		return new ModelAndView("products","message",message);
	}
	
	@RequestMapping("Products/Location")
	public ModelAndView Location(@RequestParam("zip") String zip){
		String message="Location displayed for zip="+zip;
		return new ModelAndView("products","message",message);
	}
}
